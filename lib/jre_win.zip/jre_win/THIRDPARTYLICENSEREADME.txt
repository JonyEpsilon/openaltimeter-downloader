Please refer to http://java.com/thirdpartylicense
